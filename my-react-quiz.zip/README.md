# cse2102
CSE 2102 Lab 1 - Arlyn Vasquez
---
Run these commands on your terminal or VM in order to run the files:
1. git clone "https://github.com/arlynvasquez/cse2102.git"
2. cd j2023_09_19
Install Maven (if you already installed Maven go onto next part)
3. mvn compile
4. mvn site
5. mvn test
6. All tests should have ran smoothly without any errors!
