# CSE 2102 - Lab 3 - Arlyn Vasquez

### Clone this repo to your local machine in order to compile and run the code
---

## In order to clone this repo, you must:

* Use the command "git clone [URL]" in the terminal or command prompt
    * Example: git clone https://github.com/arlynvasquez/cse2102/edit/main/s2023_10_03/
* Change the directory to the lab week
    * Example: cd cse_2102/s2023_10_03
* Run the code then go to the port on the browser
    * For you, the link to view it would be: https://netid-vm.cse.uconn.edu/proxy/8000/
    * Replace netid with your actual netid
